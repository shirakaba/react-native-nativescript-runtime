//
//  NativeScript.h
//  NativeScript
//
//  Created by Yavor Georgiev on 15.07.14.
//  Copyright (c) 2014 г. Telerik. All rights reserved.
//

#import "TNSRuntime+Diagnostics.h"
#import "TNSRuntime+Inspector.h"
#import "TNSRuntime.h"
#import "TNSRuntimeInstrumentation.h"
